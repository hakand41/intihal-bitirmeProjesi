from flask import Flask, request, jsonify, render_template, abort
from config import UPLOAD_FOLDER
from upload import process_and_save_file
from compare import perform_comparison
import os
from helpers import read_text, highlight_texts

app = Flask(__name__, template_folder='templates')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@ app.route('/upload', methods=['POST'])
def upload_file():
    try:
        user_id      = request.form.get('user_id')
        content_id   = request.form.get('content_id')
        baslik       = request.form.get('baslik')
        ad_soyad     = request.form.get('ad_soyad')
        icerik_turu  = request.form.get('icerik_turu')
        uploaded_file= request.files.get('file')

        if not all([user_id, content_id, baslik, ad_soyad, icerik_turu, uploaded_file]):
            return jsonify({"error": "Tüm alanlar gereklidir."}), 400

        user_folder = os.path.join(app.config['UPLOAD_FOLDER'], baslik, ad_soyad)
        os.makedirs(user_folder, exist_ok=True)

        original_path = os.path.join(user_folder, uploaded_file.filename)
        uploaded_file.save(original_path)

        cleaned_path = process_and_save_file(original_path, user_id, content_id, icerik_turu)

        return jsonify({
            "message": "Dosya yüklendi ve işlendi.",
            "original_path": original_path,
            "cleaned_path": cleaned_path
        }), 200

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/compare', methods=['POST'])
def compare_files():
    try:
        if not request.is_json:
            return jsonify({"error": "İstek JSON olmalı."}), 415

        content_id = request.json.get('content_id')
        if not content_id:
            return jsonify({"error": "İçerik ID eksik."}), 400

        result = perform_comparison(content_id)

        if isinstance(result, float):
            return jsonify({
                "message": "Metin karşılaştırması tamamlandı.",
                "average_similarity": round(result, 4)
            }), 200

        elif isinstance(result, dict):
            return jsonify({
                "message": result.get("message", "Kod karşılaştırması tamamlandı."),
                "port": result.get("port"),
                "job_id": result.get("job_id"),
                "web_url": f"http://localhost:{result['port']}" if result.get("port") else None
            }), 200

        else:
            return jsonify({"error": "Bilinmeyen sonuç türü."}), 500

    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/compare_html', methods=['POST'])
def compare_html():
    data = request.get_json(force=True)
    for key in ('KullaniciAdi1','KullaniciAdi2','Dosya1','Dosya2','BenzerlikOrani'):
        if key not in data:
            abort(400, f"'{key}' eksik.")
    u1, u2 = data['KullaniciAdi1'], data['KullaniciAdi2']
    p1, p2 = data['Dosya1'], data['Dosya2']
    sim = data['BenzerlikOrani']

    if not os.path.isfile(p1) or not os.path.isfile(p2):
        missing = p1 if not os.path.isfile(p1) else p2
        abort(404, f"Dosya bulunamadı: {missing}")

    raw1 = read_text(p1)
    raw2 = read_text(p2)
    h1, h2 = highlight_texts(raw1, raw2)

    h1 = h1.replace('\n','<br>')
    h2 = h2.replace('\n','<br>')

    return render_template('compare.html',
        user1=u1, user2=u2,
        similarity=sim,
        text1=h1, text2=h2
    )

if __name__ == '__main__':
    app.run(debug=True)
