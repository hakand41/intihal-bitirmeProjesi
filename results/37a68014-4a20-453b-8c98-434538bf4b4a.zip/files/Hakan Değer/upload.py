# upload.py

import os
import re
from PyPDF2 import PdfReader
from docx import Document
from db_utils import get_db_connection
# config modülünün projenizde olduğunu varsayıyorum, UPLOAD_FOLDER gibi değişkenler için.
# Eğer yoksa veya farklı bir adı varsa, importu ona göre düzenlemeniz gerekebilir.
# from config import UPLOAD_FOLDER 
import nltk

# nltk.download('stopwords') # Bu satırın her çalıştığında indirme yapmaması için
                            # normalde bir kere çalıştırılıp sonra yorum satırı yapılır
                            # veya global bir yerde nltk verilerinin olduğu varsayılır.
                            # Sunucu ortamında bu sorun yaratabilir.
try:
    from nltk.corpus import stopwords
except LookupError:
    nltk.download('stopwords')
    from nltk.corpus import stopwords

# Türkçe stop-words
turkish_stop_words = set(stopwords.words('turkish'))

def turkish_lower(text_input):
    """
    Bir metni, Türkçe karakterlere (İ, I, Ö, Ü, Ç, Ş) özel önem vererek
    küçük harfe çevirir.
    """
    replacements = {
        'İ': 'i', 'I': 'ı', 'Ö': 'ö', 'Ü': 'ü', 'Ç': 'ç', 'Ş': 'ş',
        # Python'un kendi .lower() metodu genellikle Ğ -> ğ dönüşümünü doğru yapar.
        # Diğer standart harfler de .lower() ile doğru dönüşür.
    }
    output_chars = []
    for char_original in text_input:
        # Önce karakterin standart küçük harf karşılığını alalım
        char_lower_standard = char_original.lower()
        # Eğer orijinal büyük harf karakterimiz özel Türkçe haritalama listemizdeyse,
        # onu kullanalım.
        if char_original in replacements:
            output_chars.append(replacements[char_original])
        else:
            # Değilse, standart küçük harf karşılığını kullanalım.
            output_chars.append(char_lower_standard)
    return "".join(output_chars)

def extract_text_from_file(file_path):
    """
    Verilen dosya yolundan metni çıkarır.
    - PDF için tüm sayfaları birleştirir
    - DOC/DOCX için paragrafları çift yeni satırla ayırarak korur
    - Diğer dosyalar (kod, txt vb.) için ham içeriği okur
    """
    _, ext = os.path.splitext(file_path)
    ext = ext.lower()

    if ext == '.pdf':
        # PDF içeriğini doğrudan birleştir
        # PyPDF2 bazen karmaşık PDF'lerde metin çıkarırken sorun yaşayabilir.
        # Daha iyi sonuçlar için pdfplumber gibi kütüphaneler de değerlendirilebilir.
        try:
            return ''.join([page.extract_text() or '' for page in PdfReader(file_path).pages])
        except Exception as e:
            print(f"PDF okuma hatası ({file_path}): {e}")
            return "" # Hata durumunda boş metin dön
            
    elif ext in ('.docx', '.doc'):
        # Paragrafları çift yeni satır ile ayırarak koru
        try:
            return '\n\n'.join(p.text for p in Document(file_path).paragraphs)
        except Exception as e:
            print(f"DOCX/DOC okuma hatası ({file_path}): {e}")
            return "" # Hata durumunda boş metin dön

    else:
        # Kod veya düz metin dosyası: ham içeriği oku
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except Exception as e:
            print(f"Metin dosyası okuma hatası ({file_path}): {e}")
            return "" # Hata durumunda boş metin dön


def remove_document_metadata(text):
    """
    Metin içindeki başlık, içindekiler, önsöz, kaynakça ve sayfa numarası gibi
    belgedeki meta bölümleri temizler.
    Bu fonksiyon, `clean_text` içinde her bir paragraf için çağrılır.
    """
    # Desenler (?im) flag'leri ile büyük/küçük harf duyarsız ve çok satırlı modda çalışır.
    # ^ satır başını, $ satır sonunu, \b kelime sınırını ifade eder.
    patterns = [
        r'(?im)^başlık:.*$',       # "başlık:" ile başlayan satırlar
        r'(?im)^içindekiler\b.*$', # "içindekiler" kelimesiyle başlayan satırlar
        r'(?im)^önsöz\b.*$',       # "önsöz" kelimesiyle başlayan satırlar
        r'(?im)^kaynakça\b.*$',   # "kaynakça" kelimesiyle başlayan satırlar
        r'(?im)^sayfa\s*\d+\s*$'     # Sadece "sayfa" ve numara içeren satırlar (başı ve sonu)
                                   # Eğer sayfa numaraları metin içinde geçiyorsa bu desen yetersiz kalabilir.
                                   # Daha genel bir sayfa numarası temizliği için farklı bir yaklaşım gerekebilir.
    ]
    
    cleaned_text = text
    for pat in patterns:
        cleaned_text = re.sub(pat, '', cleaned_text).strip() # Her patternden sonra boşlukları temizleyebiliriz
    
    # Potansiyel olarak sadece sayfa numarası olan satırları temizlemek için ek bir kontrol
    # Bu, üstteki `sayfa \d+` deseninin tam satır eşleşmesi için daha iyi olabilir.
    # lines = cleaned_text.splitlines()
    # non_page_number_lines = []
    # for line in lines:
    # if not re.match(r'^\s*\d+\s*$', line): # Sadece sayılardan oluşan satırları atla (sayfa no olabilir)
    # non_page_number_lines.append(line)
    # cleaned_text = "\n".join(non_page_number_lines)
    
    return cleaned_text


def clean_text(text):
    """
    Metni paragraf-paragraf temizler:
      1) Başlık/paragraf yapısını korur (tamamen büyük harfli paragrafları olduğu gibi bırakır)
      2) Metadata temizleme (remove_document_metadata) her paragraf için uygulanır.
      3) Tokenizasyon, stop-word ve sayı filtresi (tek harfli tokenlar çıkarılır)
         Türkçe'ye özgü küçük harf çevirimi kullanılır.
      4) Sonuçları çift yeni satırla birleştirir
    """
    cleaned_paragraphs = []
    if not text: # Gelen metin boşsa veya None ise boş liste dön
        return ""

    for para_idx, para in enumerate(text.split('\n\n')):
        stripped = para.strip()
        if not stripped:
            continue
        
        # Tamamen büyük harfli paragrafı (başlık) olduğu gibi koru
        # Not: Başlıklar da intihal analizine dahil edilecekse, onların da temizlenmesi gerekebilir.
        # Mevcut kod başlıkları olduğu gibi bırakıyor.
        if stripped.isupper() and len(stripped) > 3: # Kısa büyük harfli ifadeleri (örn: "IBM") başlık saymayalım
            cleaned_paragraphs.append(stripped)
            continue

        # Metadata bölümlerini temizle (paragraf bazında)
        # Bu, paragrafın orijinal büyük/küçük harf yapısıyla çalışır.
        t_cleaned_metadata = remove_document_metadata(stripped)
        if not t_cleaned_metadata.strip(): # Meta veri temizlendikten sonra paragraf boş kalırsa atla
            continue

        # Kelime bazlı tokenizasyon için Türkçe'ye özgü küçük harfe çevirme
        text_to_tokenize = turkish_lower(t_cleaned_metadata)
        
        # Tokenleri bul (Unicode karakterleri destekleyen \w+)
        tokens = re.findall(r'\b\w+\b', text_to_tokenize, flags=re.UNICODE)
        
        # Tek harfli tokenlar, stop-word ve sayısal içerikleri çıkar
        # Stop-word listesi zaten küçük harfli olduğu için burada ek bir işlem gerekmez.
        filtered_tokens = [
            w for w in tokens
            if len(w) > 1  # Tek harfli tokenları çıkar
               and w not in turkish_stop_words
               and not any(ch.isdigit() for ch in w)  # Tamamı sayı olanları veya sayı içerenleri çıkar
        ]
        
        if filtered_tokens:
            cleaned_paragraphs.append(' '.join(filtered_tokens))

    # Paragrafları çift yeni satırla birleştir
    return '\n\n'.join(cleaned_paragraphs)


def process_and_save_file(file_path, user_id, content_id, icerik_turu):
    """
    Dosyayı işleyip temizlenmiş metni kaydeder ve veritabanına kaydeder.
    - PDF ve DOCX için clean_text uygulanır.
    - Diğer dosyalar (kod, txt vb.) orijinal haliyle saklanır.
    """
    # Bu fonksiyonun içeriği orijinaldeki gibi bırakılmıştır,
    # sadece clean_text çağrısını kullandığı için dolaylı olarak faydalanacaktır.
    # UPLOAD_FOLDER gibi config değişkenlerinin doğru tanımlandığından emin olun.
    try:
        _, ext = os.path.splitext(file_path)
        ext = ext.lower()
        
        # UPLOAD_FOLDER projenizin config dosyasından gelmeli
        # Örneğin: cleaned_folder = os.path.join(UPLOAD_FOLDER, 'cleaned_files')
        # if not os.path.exists(cleaned_folder):
        #     os.makedirs(cleaned_folder)

        if ext in ('.pdf', '.docx', '.doc'):
            raw_text = extract_text_from_file(file_path)
            if not raw_text.strip(): # Eğer metin çıkarılamadıysa veya boşsa
                print(f"Uyarı: {file_path} dosyasından metin çıkarılamadı veya içerik boş.")
                # Bu durumda boş bir _cleaned.txt dosyası oluşturulabilir veya işlem atlanabilir.
                # Şimdilik, boş cleaned_text ile devam edelim.
                cleaned_text = ""
            else:
                cleaned_text = clean_text(raw_text)
            
            # Orijinal dosya adının sonuna '_cleaned.txt' ekle
            # cleaned_path = os.path.join(cleaned_folder, f"{os.path.basename(file_path)}_cleaned.txt")
            cleaned_path = f"{file_path}_cleaned.txt" # Eski yapı korunuyor
            
            with open(cleaned_path, 'w', encoding='utf-8') as f:
                f.write(cleaned_text)
        else:
            # Kod/metin dosyaları için temizleme atla, orijinal dosya yolunu kullan
            cleaned_path = file_path

        # Veritabanına temizlenmiş dosya yolunu kaydet
        # get_db_connection fonksiyonunuzun doğru çalıştığını varsayıyoruz.
        conn = get_db_connection()
        cursor = conn.cursor()
        # SQL Injection riskini azaltmak için parametreli sorgu kullanımı önemlidir.
        # Dosya yollarını veritabanına kaydederken güvenlik kontrolleri yapılmalıdır.
        cursor.execute(
            "INSERT INTO Dosyalar (CleanedPath, KullaniciId, IcerikId) VALUES (?, ?, ?)",
            (cleaned_path, user_id, content_id)
        )
        conn.commit()
        conn.close()

        return cleaned_path
    except Exception as e:
        # Hata loglama burada daha detaylı yapılabilir.
        print(f"Dosya işleme hatası ({file_path}): {e}")
        raise RuntimeError(f"Dosya işleme hatası: {e}")

# Eğer bu dosya doğrudan çalıştırılıyorsa test amaçlı bir blok eklenebilir:
if __name__ == '__main__':
    # Test için örnek metinler
    test_text_1 = "Bu bir İNTİHAL denemesidir. IŞIK önemlidir."
    test_text_2 = "ÖZGEÇMİŞ\n\nİlk satır normal. İkinci SATIR BÜYÜK. Üçüncüde sayfa 5 var."
    test_text_3 = "içindekiler\n\nBu bölüm gitmeli.\n\nAsıl metin burada."
    test_text_4 = "BİLGİSAYAR ve IŞIK."

    print("------- Test 1 -------")
    raw_1 = test_text_1
    print(f"Orijinal: {raw_1}")
    cleaned_1 = clean_text(raw_1)
    print(f"Temizlenmiş: {cleaned_1}")
    # Beklenen: "intihal denemesidir ışık önemlidir"

    print("\n------- Test 2 -------")
    raw_2 = test_text_2
    print(f"Orijinal:\n{raw_2}")
    cleaned_2 = clean_text(raw_2)
    print(f"Temizlenmiş:\n{cleaned_2}")
    # Beklenen:
    # ÖZGEÇMİŞ
    #
    # ilk satır normal ikinci SATIR BÜYÜK üçüncüde sayfa var 
    # (SATIR BÜYÜK korunur, "sayfa 5" -> "sayfa") - Not: "sayfa 5" metadata ile silinmez, 
    # sadece "sayfa \d+" regex'i tam satır ise siler. Kelime içindeki "5" any(isdigit) ile silinir.

    print("\n------- Test 3 -------")
    raw_3 = test_text_3
    print(f"Orijinal:\n{raw_3}")
    cleaned_3 = clean_text(raw_3)
    print(f"Temizlenmiş:\n{cleaned_3}")
    # Beklenen: (içindekiler satırı remove_document_metadata ile silinir)
    # (boşluk)
    #
    # asıl metin burada

    print("\n------- Test 4 -------")
    raw_4 = test_text_4
    print(f"Orijinal: {raw_4}")
    cleaned_4 = clean_text(raw_4)
    print(f"Temizlenmiş: {cleaned_4}")
    # Beklenen: "bilgisayar ışık"
    
    print("\n------- Problematic PDF text example -------")
    # Bu örnek, PDF'ten "BİLGİSAYAR" kelimesinin "BI LGI SAYAR" (boşluklu ve büyük I ile)
    # şeklinde hatalı çıkarıldığını varsayar.
    # pdf_extracted_text_sample = "BI LGI SAYAR ve İLK IŞIKLAR"
    # print(f"PDF'ten (hatalı) çıkarılan: {pdf_extracted_text_sample}")
    # cleaned_pdf_sample = clean_text(pdf_extracted_text_sample)
    # print(f"Temizlenmiş (hatalı çıkarım sonrası): {cleaned_pdf_sample}")
    # Eğer extract_text_from_file -> "BI LGI SAYAR" verirse:
    # turkish_lower("BI LGI SAYAR") -> "bı lgı sayar"
    # tokens: ['bı', 'lgı', 'sayar']
    # sonuç: "bı lgı sayar" olur.
    # Bu, "bi lgi sayar" sorununu çözmez, çünkü o sorun extraction kaynaklı olabilir.
    # Ama "İLK" -> "ilk", "IŞIKLAR" -> "ışıklar" dönüşümleri doğru olur.